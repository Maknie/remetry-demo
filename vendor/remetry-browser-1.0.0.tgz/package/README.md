# @remetry/browser

Browser SDK for **Remetry** — error, performance, API and session-replay
monitoring for web apps. ESM-only.

## Install

```bash
npm install @remetry/browser
# session replay is optional and lazy-loaded:
npm install rrweb@2.0.1
```

## Quick start

```ts
import { init, errorsPlugin, performancePlugin, apiPlugin, replayPlugin } from "@remetry/browser";

init({
  dsn: "<your-public-dsn>",
  endpoint: "https://<your-ingest-host>/ingest/events",
  release: "1.0.0",
  integrations: [errorsPlugin(), performancePlugin(), apiPlugin(), replayPlugin()],
});
```

React error boundary (separate entry, so non-React hosts never pull in React):

```tsx
import { ErrorBoundary } from "@remetry/browser/react";

<ErrorBoundary fallback={<Crashed />}>
  <App />
</ErrorBoundary>;
```

## Entry points

- `@remetry/browser` — `init`, `captureError`, `captureEvent`, `flush`,
  `getSessionId`, `shutdown`, `getClient`, plus the `errorsPlugin`,
  `performancePlugin`, `apiPlugin` and `replayPlugin` integrations.
- `@remetry/browser/react` — `ErrorBoundary`.

## Peer dependencies

- `react` (optional) — only for the `/react` entry.
- `rrweb@2.0.1` (optional) — only when you use `replayPlugin()`; loaded dynamically.
